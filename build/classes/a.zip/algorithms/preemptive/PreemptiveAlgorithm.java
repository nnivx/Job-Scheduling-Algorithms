/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package algorithms.preemptive;

import algorithms.AbstractSchedulingAlgorithm;
import classes.AlgorithmResult;
import classes.Job;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.TreeMap;

/**
 *
 * @author mxiii
 */
public abstract class PreemptiveAlgorithm extends AbstractSchedulingAlgorithm {

    static class JobData {
        public float end_time;
        public float remaining_time;

        public JobData(Job src) {
            this.end_time = 0;
            this.remaining_time = src.burst_time;
        }
    }

    private final TreeMap<Job, JobData> map;

    /**
     * @param name The name of the algorithm
     */
    public PreemptiveAlgorithm(String name) {
        super(name);
        this.map = new TreeMap<>(new Comparator<Job>(){
            @Override
            public int compare(Job a, Job b) {
                if (a.arrival_time > b.arrival_time)
                    return 1;
                else if (a.arrival_time < b.arrival_time)
                    return -1;
                else
                    return 0;
            }
        });
    }

    @Override
    public AlgorithmResult processJobs(Job[] jobs) {
        // clear the job data map
        map.clear();
        
        // set their remaining time
        for (Job e: jobs)
            map.put(new Job(e), new JobData(e));

        // call superclass' processjobs
        return super.processJobs(jobs);
    }

    protected abstract boolean preempts(Job current, Job preempting);

    protected Job[] getArrivingJobs(float endtime) {
        ArrayList<Job> ar = new ArrayList<>();
        for (Job e: jobs) {
            if (e.arrival_time > endtime)
                break;
            else
                ar.add(e);
        }
        return (Job[])ar.toArray();
    }

    protected Job getPreemptingJob(Job current, Job[] jobs) {
        Job re = current;
        for (Job e: jobs)
            re = getPreemptingJob(re, e);
        return re;
    }

    protected Job getPreemptingJob(Job current, Job job) {
        if (preempts(current, job)) {
            return job;
        }
        else
            return current;
    }

    /**
     * Returns the job that takes priority.
     *
     * This call automatically stores the preempted job's remaining
     * time, and is recursive, meaning the most preempting job is
     * returned. If current_job is null, it means that it the cpu
     * is idle until endtime.
     *
     * @param current_job
     * @param endtime
     * 
     * @return
     */
    protected Job preempt(Job current_job, float endtime) {
        Job re = null;
        float et;
        
        if (current_job == null) {
            System.out.format("preempt(%s, %f)\n", "idle", endtime);
            et = endtime;
        } else {
            System.out.format("preempt(%s, %f)\n", current_job.name, endtime);
            et = endtime + getRemainingTime(current_job);
        }
        
        
        if (!jobs.isEmpty() && first().arrival_time <= et) {
            
            Job j = jobs.pollFirst();

            if (current_job == null)
                return preempt(j, et);

            if (preempts(current_job, j)) {
                setRemainingTime(current_job, et - j.arrival_time);

                // set conditional et to arrival time of j
                et = j.arrival_time;
            System.out.format("preemptA(%s, %f)\n", "idle", endtime);
                re = preempt(j, et);

            } else {
                pending_jobs.add(j);
            System.out.format("preemptB(%s, %f)\n", "idle", endtime);
                re = preempt(current_job, endtime);
            }
        }

        return re;
    }

    protected float getRemainingTime(Job j) throws NullPointerException {
        if (!map.containsKey(j))
            throw new NullPointerException();
        return map.get(j).remaining_time;
    }

    protected void setRemainingTime(Job j, float f) throws NullPointerException {
        if (!map.containsKey(j))
            throw new NullPointerException();
        map.get(j).remaining_time = f;
    }
}
