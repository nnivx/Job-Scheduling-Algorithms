/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package algorithms.preemptive;

import classes.AlgorithmResult;
import classes.Job;

/**
 *
 * @author mxiii
 */
public class ShortestRemainingTimeFirst extends PreemptiveAlgorithm {

    public ShortestRemainingTimeFirst() {
        super("Shortest Remaining Time First (SRTF)");
    }

    @Override
    protected AlgorithmResult doAlgorithm() {
        return new AlgorithmResult();
    }

    @Override
    protected boolean preempts(Job current, Job preempting) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    

}
