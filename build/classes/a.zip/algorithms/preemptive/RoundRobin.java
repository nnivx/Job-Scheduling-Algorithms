/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package algorithms.preemptive;

import classes.AlgorithmResult;
import classes.Job;

/**
 *
 * @author mxiii
 */
public class RoundRobin extends PreemptiveAlgorithm {

    public static final float DEFAULT_TIMESPLICE = 3f;
    float timesplice;

    public RoundRobin(float timesplice) {
        super("Round Robin (RR)");
            
        try {
            setTimeSplice(timesplice);
        } catch (Exception e) {
            this.timesplice = DEFAULT_TIMESPLICE;
        }
    }

    public RoundRobin() {
        this(DEFAULT_TIMESPLICE);
    }

    @Override
    protected AlgorithmResult doAlgorithm() {
        AlgorithmResult re = new AlgorithmResult();
        re.job_count = jobs.size();

        Job curr = first();
        float et = first().arrival_time;

        // we will loop in an unoptimized way and
        // process only either per loop
        //  (a) process a job
        //  (b) set the idle time
        while (true) {
            if (!jobs.isEmpty()) {
                System.out.println("in parent-if");
                // preempt arrived jobs first
                Job j = preempt(curr, et);

                // if there is a job to process, but:

                // (a) no jobs arrived until the end time, therefore see (b)
                // (b) no pended jobs from previous call, therefore see (c)
                // (c) no pending jobs to process at all

                // it means the cpu is idling
                if (pending_jobs.isEmpty()) {
                    float at = first().arrival_time;

                    //appendChartData("**", at - et, at);
                    et = at; // idle time ends when a job has arrived.
                    curr = null;

                    // we finished our task, so loop again
                    continue;
                } else {
                    // if curr is preempted, apply necessary changes
                    if (j != curr) {
                        if (curr != null)
                            //appendChartData(curr.name, j.arrival_time - et, j.arrival_time);
                        //else
                            //appendChartData("**", j.arrival_time - et, j.arrival_time);
                        curr = j;
                    }
                }
            }
            // Below is self explanatory, just read the statement (^_^)
            else if (pending_jobs.isEmpty()) break;

            Job j = pending_jobs.getFirst(); // getFirst removes the job

            et = et + getTimeSplice();

            // we will compute everything later
            float upd = Math.min(getTimeSplice(), getRemainingTime(j));
            setRemainingTime(j, getRemainingTime(j) - upd);

            //appendChartData(j.name, upd, et);
            
            // the job is not yet done, push it back.
            if (getRemainingTime(j) > 0) {
                pending_jobs.push(j);
            }
        }

        return re;
    }

    public final void setTimeSplice(float t) throws Exception {
        if (timesplice == 0f)
            throw new Exception("Time splice must not be zero.");
        timesplice = t;
    }

    public final float getTimeSplice() {
        return timesplice;
    }

    @Override
    protected boolean preempts(Job current, Job preempting) {
        // in roundInvalid robin, any job will not preempt the current job
        return false;
    }

}
