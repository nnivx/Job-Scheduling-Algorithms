/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package algorithms.preemptive;

import classes.AlgorithmResult;
import classes.Job;

/**
 *
 * @author mxiii
 */
public class PreemptivePriority extends PreemptiveAlgorithm {

    public PreemptivePriority() {
        super("Preemptive Priority (PP)");
    }

    @Override
    protected AlgorithmResult doAlgorithm() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    protected boolean preempts(Job current, Job preempting) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }


}
