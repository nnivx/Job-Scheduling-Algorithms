/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package algorithms.nonpreemptive;

import classes.Job;
import java.util.Iterator;

/**
 *
 * @author mxiii
 */
public class ShortestJobFirst extends NonPreemptiveAlgorithm {

    public ShortestJobFirst() {
        super("Shortest Job First (SJF)");
    }

    @Override
    protected Job getJob() {
        Iterator<Job> iter = pending_jobs.iterator();
        Job lowest = iter.next();
        while (iter.hasNext()) {
            Job temp = iter.next();
            if (temp.burst_time < lowest.burst_time) {
                lowest = temp;
            }
        }
        return lowest;
    }
}
