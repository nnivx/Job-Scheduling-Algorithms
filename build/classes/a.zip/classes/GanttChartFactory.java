/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package classes;

/**
 * Factory class used by Scheduling algorithms.
 *
 * This class exist to create GanttCharts without
 * worrying about refactoring all the algorithms.
 *
 * Modify this if you want a different gantt chart
 *
 * @author mxiii
 */
public final class GanttChartFactory {

    /**
     * Returns a custom gantt chart object.
     *
     * @deprecated Initial arrival time unused
     * @param initial_arrival_time
     *
     * @return some gantt chart
     */
    public static GanttChart create(float initial_arrival_time) {
        // return Regular Gantt Chart, or a subclass, or an overriden display()
        return create();
    }

    public static GanttChart create() {
        // return Regular Gantt Chart, or a subclass, or an overriden display()
        return new gui.GanttChartGUI();
    }

    public static GanttChart create(GanttChart a) {
        return a.copy();
    }
}
