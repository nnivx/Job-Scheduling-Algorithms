/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package classes;


/**
 * Utility class for wrapping job information.
 *
 * @author mxiii
 */
public class Job {
    public final static String IDLE = "idle";

    public String name;

    public float arrival_time;

    public float burst_time;

    public int priority;

    public Job(String name, float arrival_time, float burst_time, int priority) {
        this.name = name;
        this.arrival_time = arrival_time;
        this.burst_time = burst_time;
        this.priority = priority;
    }

    public Job(Job copy) {
        this.name = copy.name;
        this.arrival_time = copy.arrival_time;
        this.burst_time = copy.burst_time;
        this.priority = copy.priority;
    }

    public static Job idle(float duration, float start_time) {
        return new Job(IDLE, start_time, duration, 0);
    }

    public static Job idleUntil(float start_time, float end_time) {
        return idle(end_time - start_time, start_time);
    }

}
