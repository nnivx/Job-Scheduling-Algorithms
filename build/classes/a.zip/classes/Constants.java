/*
 * Copyright (C) 2014 mxiii
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package classes;

/**
 * Contains constants in which the internal logic and GUI will agree upon.
 *
 * @author mxiii
 */
public interface Constants {
    /**
     * The fields. This is used for indexing arrays by
     * their ordinal (index) values. Other inconvenient
     * uses may produce subtle bugs (actual value different
     * from ordinal position).
     */
    enum JobField {
        NAME,
        ARRIVAL_TIME,
        BURST_TIME,
        PRIORITY
    }
}
